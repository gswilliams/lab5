<?php



include ("config1.php");


$bookid = trim($_GET['bookid']); // gets book id from url 
echo '<INPUT type="hidden" name="bookid" value=' . $bookid . '>'; // 

$bookid = trim($_GET['bookid']);      // Getting book id
$bookid = addslashes($bookid);

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

    if ($db->connect_error) {
        echo "CONNECTION ERROR: could not connect: " . $db->connect_error;
        printf("<br><a href=indexlab3.php>Return to home page </a>");
        exit();
    }
    
   echo "Reservation successful! You have reserved our book with ID:"           .$bookid;

    // Prepare an update statement and execute it
    $stmt = $db->prepare("UPDATE books SET onloan=1 WHERE bookid = ?"); //update books and set selected book onloan
    $stmt->bind_param('i', $bookid);
    $stmt->execute();
    printf("<br>Book Reserved!");
    printf("<br><a href=browselab4.php>Search and reserve more Books </a>");
    printf("<br><a href=mybookslab4.php>Return to your Books </a>");
    printf("<br><a href=indexlab4.php>Return to home page </a>");
    exit;
    

