<?php 
$current_page = end(explode('/', $_SERVER['REQUEST_URI']));
$dbname = 'library';
$dbuser = 'root';
$dbpass = 'root';
$dbserver = 'localhost';
?>