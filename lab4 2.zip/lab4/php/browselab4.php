
<html>
<head>
	<title>TheBookClub</title>
	<link rel="stylesheet" type="text/css" href="../css/csslab1.css">
	<link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600" rel="stylesheet">	
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,900" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:100" rel="stylesheet">
</head>

<body>
	<div id="pagecontainer">
		<header>

			<?php
			include 'config1.php';
			$title = "Search books";
			include 'header.php'; 
			?>
		</header> 

		<div id="browsform">
			<p class="titlepage">Browse books.</p>
			<p class="titledescript">Search for books in our library.</p>
			
			<form action="browselab4.php" method="POST">
				<table cellpadding="6">
					<tbody>
						<tr>
							<td>Title:</td>
							<td><input type="text" name="searchtitle"></td>
						</tr>
						
						<tr>
							<td>Author:</td>
							<td><input type="text" name="searchauthor"></td>
						</tr>

						<tr>
							<td></td>
							<td><input type="submit" name="submit" value="Submit It"></td>
						</tr>
					</tbody>
				</table>
			</form>


			<p class="titlepage">Booklist</p>
			


			<?php 
$searchtitle = "";
$searchauthor = "";

if (isset($_POST) && !empty($_POST)) {
# Get data from form
    $searchtitle = trim($_POST['searchtitle']);
    $searchauthor = trim($_POST['searchauthor']);
}



$searchtitle = addslashes($searchtitle);
$searchauthor = addslashes($searchauthor);

# Open the database
@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

if ($db->connect_error) {
    echo "could not connect: " . $db->connect_error;
    printf("<br><a href=index.php>Return to home page </a>");
    exit();
}

# Build the query. Users are allowed to search on title, author, or both

$query = " select * from books";  // Seect all from books
if ($searchtitle && !$searchauthor) { // Title only
    $query = $query . " where title like '%" . $searchtitle . "%'"; //any title containing what is entered 
}
if (!$searchtitle && $searchauthor) { // Author search only
    $query = $query . " where author like '%" . $searchauthor . "%'"; //any author containing what is entered
}
if ($searchtitle && $searchauthor) { // Title and Author search
    $query = $query . " where title like '%" . $searchtitle . "%' and author like '%" . $searchauthor . "%'"; // unfinished
}


 

//Printing information 

    $stmt = $db->prepare($query); //prepare query for execution
    $stmt->bind_result($bookid, $author, $title, $onloan); // whatever is taken out has to be assigned (to right place)
    $stmt->execute(); // Goes to DB, process, gives data back, store data 

    echo '<table bgcolor="#e7e7e7" cellpadding="10">';
    echo '<tr><td>ID</td> <b><td>Title</td> <td>Author</td> <td>Reserved?</td> <td>Reserve</td> </b> </tr>';
    while ($stmt->fetch()) {
    	if($onloan == 0) // if the book is not on loan
    		$onloan='NO'; // say no 
    	else $onloan='YES'; // else say yes

        echo "<tr>";
        echo "<td> $bookid </td><td> $title </td><td> $author </td><td> $onloan </td>";
        echo '<td><a href="reserveBook.php?bookid=' . urlencode($bookid) . '"> Reserve </a></td>';
        echo "</tr>";
    }
    echo "</table>";
    ?>

		<footer> 
			<?php include 'footer.php'; ?>	
		</footer>

</div>



</body>
</html>