
<?php

include("config1.php");

$bookid = trim($_GET['bookid']); // gets book id from url
echo '<INPUT type="hidden" name="bookid" value=' . $bookid . '>';

$bookid = trim($_GET['bookid']);      // getting book id 
$bookid = addslashes($bookid);

@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

    if ($db->connect_error) {
        echo "could not connect: " . $db->connect_error;
        printf("<br><a href=indexlab4.php>Return to home page </a>");
        exit();
    }
    
   echo $bookid;

    // Prepare an update statement and execute it
    $stmt = $db->prepare("UPDATE books SET onloan=0 WHERE bookid = ?"); // update db book, return selected book
    $stmt->bind_param('i', $bookid);
    $stmt->execute();
    printf("<br>Succesfully returned!");
    printf("<br><a href=browselab4.php>Search and Book more Books </a>");
    printf("<br><a href=mybookslab4.php>Return to Reserved Books </a>");
    printf("<br><a href=indexlab4.php>Return to home page </a>");
    exit;

?>

     


