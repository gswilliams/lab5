
		<figure id="heading">
			<img id="headimg" src="../img/headershelf.png">
		</figure> 

		<nav>
			<ul id="pagenav">
				<li class="topnav"><a class="<?php echo ($current_page == 'indexlab4.php' || $current_page == '') ? 'active' : NULL ?>" href="http://localhost:8888/lab4/php/indexlab4.php">home</a></li>
				<li class="topnav"><a class="<?php echo ($current_page == 'aboutlab4.php') ? 'active' : NULL ?>" href="http://localhost:8888/lab4/php/aboutlab4.php">about us</a></li>
				<li class="topnav"><a class="<?php echo ($current_page == 'browselab4.php') ? 'active' : NULL ?>"" href="http://localhost:8888/lab4/php/browselab4.php">browse books</a></li>
				<li class="topnav"><a class="<?php echo ($current_page == 'mybookslab4.php') ? 'active' : NULL ?>"" href="http://localhost:8888/lab4/php/mybookslab4.php">my books</a></li>
				<li class="topnav"><a class="<?php echo ($current_page == 'gallerylab4.php') ? 'active' : NULL ?>"" href="http://localhost:8888/lab4/php/gallerylab4.php">gallery</a></li>
				<li class="topnav"><a class="<?php echo ($current_page == 'contactlab4.php') ? 'active' : NULL ?>"" href="http://localhost:8888/lab4/php/contactlab4.php">contact</a></li>
				<li class="topnav"><a class="<?php echo ($current_page == 'SQLInjection.php') ? 'active' : NULL ?>"" href="http://localhost:8888/lab4/php/SQLInjection.php">log in</a></li>
			</ul>
		</nav>
