<?php

#only accepting users from http 
ini_set('session.cookie_httponly', true);



#starting session
session_start ();

#checking is user IP is not set
if (isset($_SESSION['userip']) === false){
    
    #storing IP into session userip
    $_SESSION['userip'] = $_SERVER['REMOTE_ADDR'];
}


#checking is session generated IP is the same as user - if not - unset and destroy session
if ($_SESSION['userip'] !== $_SERVER['REMOTE_ADDR']){
    session_unset();
    session_destroy();
    
}