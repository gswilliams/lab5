<!DOCTYPE html>
<html>
<head>
	<title>TheBookClub</title>
	<link rel="stylesheet" type="text/css" href="../css/csslab1.css">
	<link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600" rel="stylesheet">	
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,900" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:100" rel="stylesheet">
</head>
	<?php include 'config.php'; ?>
<body>
	<div id="pagecontainer">
		<header>
			<?php include 'header.php'; ?>
		</header> 

		<div id="maincontent">
			<div class="post">
				<p class="postinfo">4 sep / Book of the week</p>
				
				<figure>
					<img id="postimg1" src="../img/post1.png">
				</figure>

				<p class="postheading">
					New York by Paul Auster
				</p>

				<p class="bodytxt">
					Cras id est felis. Nunc egestas semper orci in malesuada. Nam aliquam eget mauris id consectetur. Sed ut nisi vel ex sagittis eleifend vitae a metus. In id accumsan dui. Quisque imperdiet elit mauris, in ornare metus placerat eget. Vestibulum venenatis nisl sit amet vulputate venenatis. Nulla varius eget turpis quis condimentum. Donec fringilla tortor metus, vitae rhoncus mi ornare ac. Aenean at nisl at dolor pellentesque porta. Curabitur accumsan dui vitae magna pharetra gravida. Cras ornare cursus dolor, quis laoreet ligula finibus in. Cras nulla purus, fringilla sit amet justo eget, tempor blandit neque. Donec eget pretium ex. Proin aliquam velit sed ex scelerisque lacinia.
				</p>
				<p class="bodytxt">
					Quisque sed justo pulvinar, porttitor lacus sit amet, viverra elit. Suspendisse id lacinia metus. Nullam dapibus mauris vel ipsum mollis, id tincidunt justo lacinia. Quisque turpis ipsum, faucibus lobortis vulputate eu, porttitor ut mi. Nunc non elementum odio. Vestibulum lacinia ligula ut erat pellentesque feugiat. Vivamus sed imperdiet erat, ut pellentesque nisi. Praesent faucibus tortor dui. Vestibulum pulvinar enim consectetur felis malesuada, a porta odio varius. Integer facilisis rhoncus arcu id euismod. Nunc viverra diam ut orci 
					Phasellus placerat augue eu tristique lacinia. Curabitur porttitor finibus nibh at iaculis. Integer id elit tempor felis hendrerit gravida. Phasellus sed libero libero. Maecenas quis erat sed leo pretium imperdiet. Nam orci tellus, porttitor ac dapibus ut, placerat eu leo. Cras accumsan orci ac nunc ultrices sodales. Duis elementum enim nulla, non iaculis erat congue quis. Integer non eros id arcu lacinia pulvinar sed et tortor. Donec sodales aliquet volutpat. Aliquam ullamcorper purus eget volutpat pharetra. Integer non ipsum nisi. Cras nisl eros, luctus sed posuere at, cursus non arcu.

				</p>
			</div> 


			<div class="post">
				<p class="postinfo">24 aug / Lorem Cras Nunc</p>
				
				<figure>
					<img id="postimg2" src="../img/post2.png">
				</figure>

				<p class="postheading">
					Curabitur accumsan dui
				</p>

				<p class="bodytxt">
					Quisque sed justo pulvinar, porttitor lacus sit amet, viverra elit. Suspendisse id lacinia metus. Nullam dapibus mauris vel ipsum mollis, id tincidunt justo lacinia. Quisque turpis ipsum, faucibus lobortis vulputate eu, porttitor ut mi. Nunc non elementum odio. Vestibulum lacinia ligula ut erat pellentesque feugiat. Vivamus sed imperdiet erat, ut pellentesque nisi. Praesent faucibus tortor dui. Vestibulum pulvinar enim consectetur felis malesuada, a porta odio varius. Integer facilisis rhoncus arcu id euismod. Nunc viverra diam ut orci Phasellus placerat augue eu tristique lacinia. Curabitur porttitor finibus nibh at iaculis. Integer id elit tempor felis hendrerit gravida. Phasellus sed libero libero. Maecenas quis erat sed leo pretium imperdiet. Nam orci tellus, porttitor ac dapibus ut, placerat eu leo. Cras accumsan orci ac nunc ultrices sodales. Duis elementum enim nulla, non iaculis erat congue quis. Integer non eros id arcu lacinia pulvinar sed et tortor. Donec sodales aliquet volutpat. Aliquam ullamcorper purus eget volutpat pharetra. Integer non ipsum nisi. Cras nisl eros, luctus sed posuere at, cursus non arcu.
				</p>
			</div> 
		</div>

		<footer> 
			<?php include 'footer.php'; ?>	
		</footer>

	</div>

</body>
</html>