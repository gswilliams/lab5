<!DOCTYPE html>
<html>
<head>
    <title>TheBookClub</title>
    <link rel="stylesheet" type="text/css" href="../css/csslab1.css">
    <link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600" rel="stylesheet">    
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=RSoboto+Slab:100" rel="stylesheet">
</head>
    <?php include 'config1.php'; ?>
<body>
    <div id="pagecontainer">
        <header>
            <?php include 'header.php'; ?>
        </header> 

              <?php
                $folder_path = '../uploadedfiles/'; 
                #Path to the folder where pictures are located 

                $num_files = glob($folder_path . "*.{JPG,jpg,gif,png,bmp}", GLOB_BRACE);
                #glob() function searches for all the pathnames matching the given pattern (jpg, gif, png etc..) the GLOB_BRACE expands {jpg, gif, png} to match 'jpg', 'gif', 'png'

                $folder = opendir($folder_path);
                #Opens upp directory "folderpath" - which is where the photos are stored.

                if($num_files > 0)
                #If there are more than 0 files in the folder -->
                {

                 while(false !== ($file = readdir($folder)))
                 {
                #While $file is directed to "right" entry from foldername do (readdir = reading entry from directory handle) -->

                  $file_path = $folder_path.$file;
                  #File path is asigned to files in folderpath"
                  
                  $extension = strtolower(pathinfo($file ,PATHINFO_EXTENSION));
                   #the chosen files extension are returned and turned to lowercase before being assigned to new variable $extension.
                  if($extension=='jpg' || $extension =='png' || $extension == 'gif' || $extension == 'bmp')
                  {#If the extension are one of the accepted echo out pictures with the height of 250 -->
                   ?>
                        <a href="<?php echo $file_path; ?>"><img src="<?php echo $file_path; ?>"  height="250" /></a>
            <?php
  }
 }
}
else
{#ELSE / if not - echo out "empty folder" and close directory foldername where pictures are stored.-->
 echo "empty folder";
}
closedir($folder);
?>

        <footer> 
            <?php include 'footer.php'; ?>      
        </footer>

    </div>

</body>
</html>