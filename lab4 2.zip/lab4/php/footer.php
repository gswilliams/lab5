<nav>
	<ul id="footnav">
		<li class="botnav"><a href="http://localhost:8888/lab4/php/indexlab4.php">home</a></li>
		<li class="botnav"><a href="http://localhost:8888/lab4/php/aboutlab4.php">about us</a></li>
		<li class="botnav"><a href="http://localhost:8888/lab4/php/browselab4.php">browse books</a></li>
		<li class="botnav"><a href="http://localhost:8888/lab4/php/mybookslab4.php">my books</a></li>
		<li class="botnav"><a href="http://localhost:8888/lab4/php/gallery.php">gallery</a></li>
		<li class="botnav"><a href="http://localhost:8888/lab4/php/contactlab4.php">contact</a></li>
	</ul>
</nav>	
