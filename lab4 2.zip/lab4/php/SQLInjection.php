<?php

include 'config1.php';


#connection to new table in database

@ $db = new mysqli('localhost', 'root', 'root', 'testinguser');

# If not able to connect to db show error
if ($db->connect_error) {
    echo "could not connect: " . $db->connect_error;
    printf("<br><a href=index.php>Return to home page </a>");
    exit();
}


    #checking if usr name and pass is set
if (isset($_POST['username'], $_POST['userpass'])) {

    #statement making it SQL Injection-proof
    $uname = htmlentities($db, $_POST['username']);
    $uname = mysqli_real_escape_string($db, $_POST['username']);
    

    #creating var for hashed pass
    $upass = sha1($_POST['userpass']);
    
    
    #opening db with all users 
    $query = ("SELECT * FROM user WHERE username = '{$uname}' "."AND userpass = '{$upass}'");
       
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $stmt->store_result(); 
    
    
    #checking if user exist in db
    $totalcount = $stmt->num_rows();        
}

?>
<!DOCTYPE html>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <p id="bodytxt">Please enter username and password to log in:</p>
        <?php
        
        
        
        if (isset($totalcount)) {
            if ($totalcount == 0) {
                echo '<h2>You entered wrong password</h2>';
            } else {
                echo "<a href=fileUpload.php>Welcome, press here to upload pictures </a>";
 
            }
        }
        ?>
        <form method="POST" action="">
            <input type="text" name="username">
            <input type="password" name="userpass">
            <input type="submit" value="Go">
        </form>

    </body>
</html>
