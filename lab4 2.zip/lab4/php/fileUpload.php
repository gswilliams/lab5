<?php

# Checking if file is set - If user clicks submit
if (isset($_FILES['upload'])){  
    
    #Creating array of allowed file-extensions, only pictures
    $allowedextensions = array('jpg', 'jpeg', 'gif', 'png');
    
 
    #Creating an array for chosen files extension - Taking extension out of selected file in order to see if it is correct. Substr takes out part of string, strpos chooses what part, starting from dot, strtolower makes it lowercase to possibly fit array of allowed extensions.
    $extension = strtolower(substr($_FILES['upload']['name'], strrpos($_FILES['upload']['name'], '.') + 1));
    
    #Echoing out choosen file extension
    echo "The file you uploaded is a : ".$extension;
    
    #creating array for all possible errors, for later use 
    $error = array ();
    
    
    #checking if choosen extension is in the array for allowed extensions
    if(in_array($extension, $allowedextensions) === false){
        
        #if it is not, new error placed in error array
        $error[] = 'This is not an image, upload is allowed only for images.';        
    }
    
    #checking if chosen file is bigger than allowed limit of 1MB 
    if($_FILES['upload']['size'] > 1000000){
        
        #If it is, new error placed in error array
        $error[]='The file exceeded the upload limit';
    }
    
    
    
    #Checking if error array is empty, if it is continue with next
    if(empty($error)){
        
        
        #moving chosen file to chosen destination, assigns temporary name while uploading then real.
        move_uploaded_file($_FILES['upload']['tmp_name'], "..//uploadedfiles/{$_FILES['upload']['name']}");     
    }
    
}

?>


<html>
    <head>
        <title>File upload</title>
           </head>
           
           <body>
               <div>
                   <?php 
                   
                   #checking if error array is empty 
                   if (isset($error)){
                       if (empty($error)){
                          
                           #Enable user to check uploaded file right away
                           echo '<a href="../uploadedfiles/' . $_FILES['upload']['name'] . '">Check file';
                           
                       } else {
                           
                           #If error array is not empty print errors. 
                           foreach ($error as $err){
                               echo $err;
                           }
                           
                       }
                   }
                   
                   ?>
               </div>
               

               <div>
                   
                   <form action="" method="POST" enctype="multipart/form-data">
                       <input type="file" name="upload" /></br>
                       <input  type="submit" value="submit" />
                   </form>                   
               </div>
           </body>
    
    
    
    
</html>