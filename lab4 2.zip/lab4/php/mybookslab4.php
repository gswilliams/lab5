<!DOCTYPE html>
<html>
<head>
	<title>TheBookClub</title>
	<link rel="stylesheet" type="text/css" href="../css/csslab1.css">
	<link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600" rel="stylesheet">	
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,900" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=RSoboto+Slab:100" rel="stylesheet">
</head>
	<?php include 'config1.php'; ?>
<body>
	<div id="pagecontainer">
		<header>
			<?php include 'header.php'; ?>
		</header> 

<p class="titlepage">Your reserved books.</p> 
<p class="titledescript">These are your reserved books, return by using the button on the right of the concerned book.</p>

<?php
# This is the mysqli version

$searchtitle = "";
$searchauthor = "";

if (isset($_POST) && !empty($_POST)) {
# Get the data from form
    $searchtitle = trim($_POST['searchtitle']);
    $searchauthor = trim($_POST['searchauthor']);
}



$searchtitle = addslashes($searchtitle);
$searchauthor = addslashes($searchauthor);

# Opening database
@ $db = new mysqli($dbserver, $dbuser, $dbpass, $dbname);

if ($db->connect_error) {
    echo "could not connect: " . $db->connect_error;
    printf("<br><a href=indexlab3.php>Return to home page </a>");
    exit();
}

# Building the query Users are allowed to search on title, author, or both

$query = " select title, author, onloan, bookid from books where onloan is true"; // select
if ($searchtitle && !$searchauthor) { // Title search 
    $query = $query . " and title like '%" . $searchtitle . "%'"; // any title containing what is entered
}
if (!$searchtitle && $searchauthor) { // Author search 
    $query = $query . " and author like '%" . $searchauthor . "%'"; // any author containing what is entered
}
if ($searchtitle && $searchauthor) { // Title and Author 
    $query = $query . " and title like '%" . $searchtitle . "%' and author like '%" . $searchauthor . "%'"; 
}


 

 
    $stmt = $db->prepare($query); //prepare query for execution 
    $stmt->bind_result($title, $author, $onloan, $bookid); // whatever is taken out has to be assigned
    $stmt->execute(); // Goes to DB, process, gives data back, store data 

    

    echo '<table bgcolor="#e7e7e7" cellpadding="10">';
    echo '<tr><b><td>BookID</td><b> <td>Title</td> <td>Author</td> <td>Reserved?</td> </b> <td>Return</td> </b></tr>';
    while ($stmt->fetch()) {
        if($onloan==1)
            $onloan="Yes";
       
        echo "<tr>";
        echo "<td> $bookid </td><td> $title </td><td> $author </td><td> $onloan </td>";
        echo '<td><a href="returnBook.php?bookid=' . urlencode($bookid) . '">Return</a></td>';
        echo "</tr>";
        
    }
    echo "</table>";
    ?>

		<footer> 
			<?php include 'footer.php'; ?>		
		</footer>

	</div>

</body>
</html>