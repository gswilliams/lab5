<!DOCTYPE html>
<html>
<head>
	<title>TheBookClub</title>
	<link rel="stylesheet" type="text/css" href="../css/csslab1.css">
	<link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600" rel="stylesheet">	
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,900" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:100" rel="stylesheet">
</head>
	<?php include 'config.php'; ?>
<body>
	<div id="pagecontainer">
		<header>
			<?php include 'header.php'; ?>
		</header>  

		<p class="titlepage">Contact us.</p>  
			<p class="titledescript">Feel free to contact us with any questions, we normaly respond within 24hrs.</p>
			<form id="contactform">
				<textarea id="message">Your question</textarea> 
				<input class="input" type="text" name="text" value="Name"> <br>
				<input class="input" type="text" name="text" value="E-mail"> <br>
				<input type="submit" name="">
			</form> 

		<footer> 
			<?php include 'footer.php'; ?>		
		</footer>

	</div>

</body>
</html>