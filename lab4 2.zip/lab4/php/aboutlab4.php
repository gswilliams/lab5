<!DOCTYPE html>
<html>
<head>
	<title>TheBookClub</title>
	<link rel="stylesheet" type="text/css" href="../css/csslab1.css">
	<link href="https://fonts.googleapis.com/css?family=Cormorant+Garamond:300,300i,400,400i,500,500i,600" rel="stylesheet">	
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700,900" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto+Slab:100" rel="stylesheet">
</head>
	<?php include 'config.php'; ?>
<body>
	<div id="pagecontainer">
		<header>
			<?php include 'header.php'; ?>
		</header>  
	 

	<div>
		<figure id="about">
			<img id="aboutimg" src="../img/aboutus.png">
			<p class="bodytxt">Curabitur porttitor finibus nibh at iaculis. Integer id elit tempor felis hendrerit gravida. Phasellus sed libero libero. Maecenas quis erat sed leo pretium imperdiet. Nam orci tellus, porttitor ac dapibus ut, placerat eu leo. Cras accumsan orci ac nunc ultrices sodales. Duis elementum enim nulla, non iaculis erat congue quis. Integer non eros id arcu lacinia pulvinar sed et tortor. Donec sodales aliquet volutpat. Aliquam ullamcorper purus eget volutpat pharetra. Integer non ipsum nisi. Cras nisl eros, luctus sed posuere at, cursus non arcu. Phasellus sed libero libero. Maecenas quis erat sed leo pretium imperdiet. Nam orci tellus, porttitor ac dapibus ut, placerat eu leo. Cras accumsan orci ac nunc ultrices sodales. Duis elementum enim nulla, non iaculis erat congue quis. Integer non eros id arcu lacinia pulvinar sed et tortor. Donec sodales aliquet volutpat. Aliquam ullamcorper purus eget volutpa. </p>

			<p class='bodytxt'> Integer non ipsum nisi. Cras nisl eros, luctus sed posuere at, cursus non arcu.Phasellus sed libero libero. Maecenas quis erat sed leo pretium imperdiet. Nam orci tellus, porttitor ac dapibus ut, placerat eu leo. Cras accumsan orci ac nunc ultrices sodales. Duis elementum enim nulla, non iaculis erat congue quis. Integer non eros id arcu lacinia pulvinar sed et tortor. Donec sodales aliquet volutpat. Aliquam ullamcorper purus eget volutpat pharetra. Integer non ipsum nisi. Cras nisl eros, luctus sed posuere at, cursus non arcu. Integer non eros id arcu lacinia pulvinar sed et tortor. Donec sodales aliquet.</p>

		</figure>


		<footer> 
			<?php include 'footer.php'; ?>	
		</footer>

	</div> 
	</div>

</body>
</html>